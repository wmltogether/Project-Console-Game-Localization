# -*- coding: utf-8 -*-
import base64
from pywidevine.L3.cdm import cdm, deviceconfig
from base64 import b64encode
from pywidevine.L3.decrypt.wvdecryptcustom import WvDecrypt
import json
import requests
import urllib3
import ssl

requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL'


CERT = None

class WV_Headers:
    
    def __init__(self) -> None:
        self.headers = {
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
        'Refer': 'https://hamivideo.hinet.net/',
        'Sec-Fetch-Dest': 'empty', 
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-site'
        }

        pass


pssh = 'AAAAknBzc2gAAAAA7e+LqXnWSs6jyCfc1R0h7QAAAHIIARIQpDAoL5zV+UgA9aBbDwUjthoZdmVyaW1hdHJpeGNodW5naHdhdGVsZWNvbSI7cj1PVFRfVk9EXzMzNzkxMDNkYTlmMDRiZGRiZTEzZGVkMjJlZmU5ZDY3X01SX0RBX0hMUyZzPTcwNDQqAlNEOAA='
lic = 'https://widevine.ott.hinet.net/?deviceId=NjA1NzI0ZjYtOGI4MS0zMjBkLTg4MDctYjZjYzJhZDMwOGVi'


class TLSAdapter(requests.adapters.HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.set_ciphers("ALL:@SECLEVEL=1")
        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)
    
def WV_Function(pssh, lic_url, cert_b64=None):
    headers = WV_Headers()
    req_headers = headers.headers
    print('============POST LICENSE=============')
    session = requests.Session()
    session.mount('https://', TLSAdapter())
    wvdecrypt = WvDecrypt(init_data_b64=pssh, cert_data_b64=cert_b64, device=deviceconfig.g935f)                   
    req = session.post(url=lic_url, data=wvdecrypt.get_challenge(), headers=req_headers, verify=False)
    license_b64 = b64encode(req.content) 
    wvdecrypt.update_license(license_b64)
    Correct, keyswvdecrypt = wvdecrypt.start_process()
    if Correct:
        return Correct, keyswvdecrypt   
correct, keys = WV_Function(pssh, lic)

print()
for key in keys:
    print('--key ' + key)
